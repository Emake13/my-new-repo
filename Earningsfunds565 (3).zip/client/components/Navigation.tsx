import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Home, ArrowUpRight, TrendingUp, HelpCircle } from 'lucide-react';

export const Navigation: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-border z-40 safe-area-inset-bottom">
      <div className="flex justify-around h-20">
        <button
          onClick={() => navigate('/')}
          className={`flex-1 flex flex-col items-center justify-center gap-1 transition-colors ${
            isActive('/') ? 'text-primary' : 'text-muted-foreground'
          }`}
        >
          <Home size={24} />
          <span className="text-xs font-medium">Home</span>
        </button>

        <button
          onClick={() => navigate('/withdraw')}
          className={`flex-1 flex flex-col items-center justify-center gap-1 transition-colors ${
            isActive('/withdraw') ? 'text-primary' : 'text-muted-foreground'
          }`}
        >
          <ArrowUpRight size={24} />
          <span className="text-xs font-medium">Withdraw</span>
        </button>

        <button
          onClick={() => navigate('/upgrade')}
          className={`flex-1 flex flex-col items-center justify-center gap-1 transition-colors ${
            isActive('/upgrade') ? 'text-primary' : 'text-muted-foreground'
          }`}
        >
          <TrendingUp size={24} />
          <span className="text-xs font-medium">Upgrade</span>
        </button>

        <button
          onClick={() => navigate('/support')}
          className={`flex-1 flex flex-col items-center justify-center gap-1 transition-colors ${
            isActive('/support') ? 'text-primary' : 'text-muted-foreground'
          }`}
        >
          <HelpCircle size={24} />
          <span className="text-xs font-medium">Support</span>
        </button>
      </div>
    </nav>
  );
};
