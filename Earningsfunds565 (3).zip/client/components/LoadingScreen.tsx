import React from 'react';

export const LoadingScreen: React.FC = () => {
  return (
    <div className="fixed inset-0 bg-white z-50 flex flex-col items-center justify-center">
      <div className="relative w-24 h-24 mb-8">
        {/* Animated circle progress */}
        <svg className="w-24 h-24" viewBox="0 0 100 100">
          {/* Background circle */}
          <circle
            cx="50"
            cy="50"
            r="45"
            fill="none"
            stroke="hsl(var(--secondary))"
            strokeWidth="2"
          />
          {/* Animated progress circle */}
          <circle
            cx="50"
            cy="50"
            r="45"
            fill="none"
            stroke="hsl(var(--primary))"
            strokeWidth="2"
            strokeDasharray="282.7"
            strokeDashoffset="282.7"
            strokeLinecap="round"
            style={{
              animation: 'dash 2s ease-in-out infinite',
              transformOrigin: '50px 50px',
              transform: 'rotate(-90deg)',
            }}
          />
        </svg>
        {/* Center icon */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center">
            <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20">
              <path d="M10.5 1.5H3.75A2.25 2.25 0 001.5 3.75v12.5A2.25 2.25 0 003.75 18.5h12.5a2.25 2.25 0 002.25-2.25V9.5" />
              <path d="M6.5 10l2.5 2.5 5-5" />
            </svg>
          </div>
        </div>
      </div>

      <h2 className="text-xl font-bold text-foreground mb-2">Processing withdrawal, please wait…</h2>
      <p className="text-muted-foreground text-center px-6">
        Your withdrawal request is being processed. Do not close this page.
      </p>

      <style>{`
        @keyframes dash {
          0% {
            stroke-dashoffset: 282.7;
          }
          50% {
            stroke-dashoffset: 0;
          }
          100% {
            stroke-dashoffset: -282.7;
          }
        }
      `}</style>
    </div>
  );
};
