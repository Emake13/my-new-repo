import React, { useState, useEffect } from "react";
import { X } from "lucide-react";

export const CommunityPopup: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Show popup immediately
    setIsVisible(true);

    // Set up interval to show popup every 7 seconds
    const interval = setInterval(() => {
      setIsVisible(true);
    }, 7000);

    return () => clearInterval(interval);
  }, []);

  const handleClose = () => {
    setIsVisible(false);
  };

  const handleJoinCommunity = () => {
    window.open("https://t.me/earningbyenaria", "_blank");
  };

  if (!isVisible) return null;

  return (
    <>
      {/* Overlay */}
      <div
        className="fixed inset-0 bg-black/50 z-40"
        onClick={handleClose}
      ></div>

      {/* Popup */}
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white rounded-3xl p-8 z-50 w-[90%] max-w-sm shadow-2xl">
        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
        >
          <X size={24} className="text-gray-600" />
        </button>

        {/* Content */}
        <div className="text-center">
          {/* Icon */}
          <div className="text-5xl mb-4">🚀</div>

          {/* Message */}
          <h2 className="text-2xl font-bold text-foreground mb-3">
            Join Our Community Now
          </h2>
          <p className="text-muted-foreground mb-6">
            Join Out Community now for more News and Updates
          </p>

          {/* Telegram Info */}
          <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-4 mb-6">
            <p className="text-sm text-blue-900 font-semibold mb-2">
              Join Out on Telegram 👇
            </p>
            <p className="text-xs text-blue-800 break-all">
              https://t.me/earningbyenaria
            </p>
          </div>

          {/* Buttons */}
          <div className="flex gap-3">
            <button
              onClick={handleClose}
              className="flex-1 bg-gray-200 text-gray-800 font-semibold py-3 rounded-xl hover:bg-gray-300 transition-all active:scale-95"
            >
              Close
            </button>
            <button
              onClick={handleJoinCommunity}
              className="flex-1 bg-primary text-primary-foreground font-semibold py-3 rounded-xl hover:bg-primary/90 transition-all active:scale-95"
            >
              Join Out
            </button>
          </div>
        </div>
      </div>
    </>
  );
};
