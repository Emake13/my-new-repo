import React from 'react';

interface SuccessScreenProps {
  title: string;
  message: string;
  onClose: () => void;
}

export const SuccessScreen: React.FC<SuccessScreenProps> = ({ title, message, onClose }) => {
  return (
    <div className="fixed inset-0 bg-white z-50 flex flex-col items-center justify-center px-6">
      <div className="w-20 h-20 rounded-full bg-green-500 flex items-center justify-center mb-8 animate-bounce">
        <svg className="w-10 h-10 text-white" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" stroke="currentColor">
          <path d="M5 13l4 4L19 7"></path>
        </svg>
      </div>

      <h2 className="text-2xl font-bold text-foreground mb-3 text-center">{title}</h2>
      <p className="text-muted-foreground text-center mb-8 leading-relaxed">
        {message}
      </p>

      <button
        onClick={onClose}
        className="w-full py-3 bg-primary text-primary-foreground rounded-xl font-semibold hover:bg-opacity-90 transition-all active:scale-95"
      >
        Done
      </button>
    </div>
  );
};
