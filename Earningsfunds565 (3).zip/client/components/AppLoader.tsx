import React from 'react';

export const AppLoader: React.FC = () => {
  return (
    <div className="fixed inset-0 bg-gradient-to-br from-primary to-primary/80 z-50 flex flex-col items-center justify-center">
      <div className="relative w-32 h-32 mb-8">
        <div className="absolute inset-0 rounded-full border-8 border-primary-foreground/30" />
        <div
          className="absolute inset-0 rounded-full border-8 border-transparent border-t-primary-foreground border-r-primary-foreground"
          style={{
            animation: 'spin 1.5s linear infinite',
          }}
        />
        <div className="absolute inset-4 rounded-full bg-primary-foreground/10" />
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-4xl">💰</span>
        </div>
      </div>

      <h1 className="text-3xl font-bold text-primary-foreground mb-2 text-center px-6">
        Earn Bye Naira & Supply
      </h1>
      <p className="text-primary-foreground/80 text-center px-6 mb-12">
        Loading your wealth...
      </p>

      <style>{`
        @keyframes spin {
          from {
            transform: rotate(0deg);
          }
          to {
            transform: rotate(360deg);
          }
        }
      `}</style>
    </div>
  );
};
