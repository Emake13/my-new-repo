import "./global.css";

import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { UserProvider, useUser } from "./context/UserContext";
import { AppLoader } from "./components/AppLoader";
import Dashboard from "./pages/Dashboard";
import Withdraw from "./pages/Withdraw";
import Upgrade from "./pages/Upgrade";
import Support from "./pages/Support";
import Referrals from "./pages/Referrals";
import Register from "./pages/Register";
import Login from "./pages/Login";
import WithdrawalSuccess from "./pages/WithdrawalSuccess";
import Community from "./pages/Community";
import BuyPersonalCode from "./pages/BuyPersonalCode";
import PaymentProcessing from "./pages/PaymentProcessing";
import BankTransferDetails from "./pages/BankTransferDetails";
import VerificationLoading from "./pages/VerificationLoading";
import NotVerifiedResult from "./pages/NotVerifiedResult";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const AppContent = () => {
  const { initialized, loading, isAuthenticated } = useUser();

  if (loading || !initialized) {
    return <AppLoader />;
  }

  if (!isAuthenticated) {
    return (
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="*" element={<Login />} />
      </Routes>
    );
  }

  return (
    <Routes>
      <Route path="/" element={<Dashboard />} />
      <Route path="/withdraw" element={<Withdraw />} />
      <Route path="/withdrawal-success" element={<WithdrawalSuccess />} />
      <Route path="/upgrade" element={<Upgrade />} />
      <Route path="/support" element={<Support />} />
      <Route path="/referrals" element={<Referrals />} />
      <Route path="/community" element={<Community />} />
      <Route path="/buy-personal-code" element={<BuyPersonalCode />} />
      <Route path="/payment-processing" element={<PaymentProcessing />} />
      <Route path="/bank-transfer-details" element={<BankTransferDetails />} />
      <Route path="/verification-loading" element={<VerificationLoading />} />
      <Route path="/not-verified-result" element={<NotVerifiedResult />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <BrowserRouter>
        <UserProvider>
          <AppContent />
        </UserProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
