import React, {
  createContext,
  useContext,
  useState,
  useCallback,
  useEffect,
} from "react";

export interface User {
  id: string;
  name: string;
  email: string;
  balance: number;
  referralCode: string;
  lastClaimDate: string | null;
  isNewUser: boolean;
  referralCount: number;
  referralEarnings: number;
  referredBy: string | null;
}

export interface WithdrawalDetails {
  bank: string;
  accountNumber: string;
  accountName: string;
  amount: number;
  timestamp: string;
  transactionId: string;
}

export interface StoredUserData {
  user: User;
  password: string;
}

interface UserContextType {
  user: User | null;
  isAuthenticated: boolean;
  loading: boolean;
  claimBonus: () => Promise<void>;
  addDailyBonus: () => Promise<void>;
  withdraw: (
    amount: number,
    bank: string,
    accountNumber: string,
    accountName: string,
  ) => Promise<WithdrawalDetails>;
  initialized: boolean;
  referralLink: string;
  register: (name: string, email: string, password: string, referralCode?: string) => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  lastWithdrawal: WithdrawalDetails | null;
  addReferralEarnings: (amount: number) => Promise<void>;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  const [initialized, setInitialized] = useState(false);
  const [lastWithdrawal, setLastWithdrawal] =
    useState<WithdrawalDetails | null>(null);

  // Initialize on app load
  useEffect(() => {
    const initializeApp = async () => {
      await new Promise((resolve) => setTimeout(resolve, 1500));

      const storedUser = localStorage.getItem("user");
      const authToken = localStorage.getItem("authToken");

      if (storedUser && authToken) {
        const user = JSON.parse(storedUser);

        // Load the latest user data from allUsersData to ensure we have any referral bonuses
        const allUsersData = localStorage.getItem("allUsersData");
        if (allUsersData) {
          const users: User[] = JSON.parse(allUsersData);
          const latestUserData = users.find((u) => u.id === user.id);
          if (latestUserData) {
            setUser(latestUserData);
            localStorage.setItem("user", JSON.stringify(latestUserData));
          } else {
            setUser(user);
          }
        } else {
          setUser(user);
        }
        setIsAuthenticated(true);
      } else {
        setIsAuthenticated(false);
      }

      setLoading(false);
      setInitialized(true);
    };

    initializeApp();
  }, []);

  const claimBonus = useCallback(async () => {
    if (!user) return;

    const today = new Date().toDateString();
    const lastClaim = user.lastClaimDate
      ? new Date(user.lastClaimDate).toDateString()
      : null;

    if (lastClaim === today) {
      throw new Error("You have already claimed your bonus today!");
    }

    const updatedUser = {
      ...user,
      balance: 150000,
      lastClaimDate: new Date().toISOString(),
    };

    setUser(updatedUser);
    localStorage.setItem("user", JSON.stringify(updatedUser));
  }, [user]);

  const addDailyBonus = useCallback(async () => {
    if (!user) return;

    const today = new Date().toDateString();
    const lastClaim = user.lastClaimDate
      ? new Date(user.lastClaimDate).toDateString()
      : null;

    if (lastClaim === today) {
      throw new Error("Already received daily bonus today!");
    }

    const DAILY_BONUS = 500;
    const updatedUser = {
      ...user,
      balance: user.balance + DAILY_BONUS,
      lastClaimDate: new Date().toISOString(),
    };

    setUser(updatedUser);
    localStorage.setItem("user", JSON.stringify(updatedUser));
  }, [user]);

  const withdraw = useCallback(
    async (
      amount: number,
      bank: string,
      accountNumber: string,
      accountName: string,
    ): Promise<WithdrawalDetails> => {
      if (!user) throw new Error("User not authenticated");

      if (user.balance < amount) {
        throw new Error("Insufficient balance");
      }

      // Simulate withdrawal processing
      await new Promise((resolve) => setTimeout(resolve, 3000));

      const updatedUser = {
        ...user,
        balance: user.balance - amount,
      };

      const withdrawalDetails: WithdrawalDetails = {
        bank,
        accountNumber,
        accountName,
        amount,
        timestamp: new Date().toISOString(),
        transactionId: "TXN" + Date.now(),
      };

      setUser(updatedUser);
      setLastWithdrawal(withdrawalDetails);
      localStorage.setItem("user", JSON.stringify(updatedUser));
      localStorage.setItem("lastWithdrawal", JSON.stringify(withdrawalDetails));

      return withdrawalDetails;
    },
    [user],
  );

  const register = useCallback(
    async (name: string, email: string, password: string, referralCode?: string) => {
      // Simulate registration processing
      await new Promise((resolve) => setTimeout(resolve, 1500));

      // Check if email already exists
      const allUsers = localStorage.getItem("allUsers");
      const usersList: Array<{ email: string; referralCode?: string }> = allUsers
        ? JSON.parse(allUsers)
        : [];

      const emailExists = usersList.some((u) => u.email === email);
      if (emailExists) {
        throw new Error(
          "This email is already registered. Please log in instead.",
        );
      }

      const REFERRAL_BONUS = 5000;

      const newUser: User = {
        id: Math.random().toString(36).substring(7),
        name,
        email,
        balance: 50000,
        referralCode: Math.random().toString(36).substring(2, 11).toUpperCase(),
        lastClaimDate: null,
        isNewUser: true,
        referralCount: 0,
        referralEarnings: 0,
        referredBy: referralCode || null,
      };

      // Add referral bonus if user was referred
      if (referralCode) {
        // Find the referrer user
        const allUsersStorage = localStorage.getItem("allUsersData");
        const allUsersData: User[] = allUsersStorage ? JSON.parse(allUsersStorage) : [];

        const referrerIndex = allUsersData.findIndex(
          (u) => u.referralCode === referralCode
        );

        if (referrerIndex !== -1) {
          const referrer = allUsersData[referrerIndex];
          const updatedReferrer = {
            ...referrer,
            referralCount: referrer.referralCount + 1,
            referralEarnings: referrer.referralEarnings + REFERRAL_BONUS,
            balance: referrer.balance + REFERRAL_BONUS,
          };

          // Update referrer in storage
          allUsersData[referrerIndex] = updatedReferrer;
          localStorage.setItem("allUsersData", JSON.stringify(allUsersData));

          // If the referrer is the currently logged-in user, update them
          const storedUser = localStorage.getItem("user");
          if (storedUser) {
            const currentUser = JSON.parse(storedUser);
            if (currentUser.id === referrer.id) {
              setUser(updatedReferrer);
              localStorage.setItem("user", JSON.stringify(updatedReferrer));
            }
          }
        }
      }

      // Store user data
      localStorage.setItem("user", JSON.stringify(newUser));
      localStorage.setItem("userPassword", password);

      // Add to users list for email uniqueness check and all users data
      usersList.push({ email, referralCode: newUser.referralCode });
      localStorage.setItem("allUsers", JSON.stringify(usersList));

      const allUsersData: User[] = localStorage.getItem("allUsersData")
        ? JSON.parse(localStorage.getItem("allUsersData")!)
        : [];
      allUsersData.push(newUser);
      localStorage.setItem("allUsersData", JSON.stringify(allUsersData));

      const token = Math.random().toString(36).substring(2, 11);
      setUser(newUser);
      setIsAuthenticated(true);
      localStorage.setItem("authToken", token);
    },
    [],
  );

  const login = useCallback(async (email: string, password: string) => {
    // Simulate login processing
    await new Promise((resolve) => setTimeout(resolve, 1500));

    // Try to load user from allUsersData first for latest data
    const allUsersData = localStorage.getItem("allUsersData");
    const users: User[] = allUsersData ? JSON.parse(allUsersData) : [];
    const userFromStorage = users.find((u) => u.email === email);

    if (!userFromStorage) {
      throw new Error("User not found");
    }

    // Verify password
    const storedPassword = localStorage.getItem("userPassword");
    if (storedPassword !== password) {
      throw new Error("Invalid email or password");
    }

    // Update localStorage["user"] with the latest data from allUsersData
    localStorage.setItem("user", JSON.stringify(userFromStorage));

    const token = Math.random().toString(36).substring(2, 11);
    setUser(userFromStorage);
    setIsAuthenticated(true);
    localStorage.setItem("authToken", token);
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem("authToken");
  }, []);

  const addReferralEarnings = useCallback(
    async (amount: number) => {
      if (!user) return;

      const updatedUser = {
        ...user,
        balance: user.balance + amount,
        referralEarnings: user.referralEarnings + amount,
      };

      setUser(updatedUser);
      localStorage.setItem("user", JSON.stringify(updatedUser));

      // Also update in allUsersData
      const allUsersData: User[] = localStorage.getItem("allUsersData")
        ? JSON.parse(localStorage.getItem("allUsersData")!)
        : [];
      const userIndex = allUsersData.findIndex((u) => u.id === user.id);
      if (userIndex !== -1) {
        allUsersData[userIndex] = updatedUser;
        localStorage.setItem("allUsersData", JSON.stringify(allUsersData));
      }
    },
    [user],
  );

  const referralLink = user
    ? `https://earn-bye-naria.netlify.app/?ref=${user.referralCode}`
    : "";

  return (
    <UserContext.Provider
      value={{
        user,
        isAuthenticated,
        loading,
        claimBonus,
        addDailyBonus,
        withdraw,
        initialized,
        referralLink,
        register,
        login,
        logout,
        lastWithdrawal,
        addReferralEarnings,
      }}
    >
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error("useUser must be used within UserProvider");
  }
  return context;
};
