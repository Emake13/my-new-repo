import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Copy, Check } from "lucide-react";

export default function BankTransferDetails() {
  const navigate = useNavigate();
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const handleCopy = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleMadeTransfer = () => {
    navigate("/verification-loading");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-secondary to-white pb-12 flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-br from-primary to-primary/90 text-primary-foreground px-6 py-8 text-center">
        <h1 className="text-2xl font-bold mb-2">Payment Details</h1>
        <p className="text-primary-foreground/90">
          Complete your bank transfer
        </p>
      </div>

      {/* Content */}
      <div className="flex-1 px-6 py-8">
        {/* Amount Card */}
        <div className="bg-white border-2 border-primary rounded-2xl p-6 mb-6">
          <p className="text-sm text-muted-foreground mb-2">Amount</p>
          <h2 className="text-3xl font-bold text-primary">₦4,500</h2>
        </div>

        {/* Bank Details */}
        <div className="space-y-4 mb-8">
          {/* Bank Name */}
          <div className="bg-white border-2 border-border rounded-2xl p-4">
            <p className="text-xs text-muted-foreground mb-2">Bank Name</p>
            <div className="flex items-center justify-between">
              <p className="text-lg font-semibold text-foreground">
                PalmPay Limited(PalmPay)
              </p>
              <button
                onClick={() => handleCopy("PalmPay Limited(PalmPay)", "bank")}
                className="p-2 hover:bg-primary/10 rounded-lg transition-colors"
              >
                {copiedField === "bank" ? (
                  <Check size={18} className="text-green-600" />
                ) : (
                  <Copy size={18} className="text-muted-foreground" />
                )}
              </button>
            </div>
          </div>

          {/* Account Name */}
          <div className="bg-white border-2 border-border rounded-2xl p-4">
            <p className="text-xs text-muted-foreground mb-2">Account Name</p>
            <div className="flex items-center justify-between">
              <p className="text-lg font-semibold text-foreground">
                AMARACHI GRACE NJOKU
              </p>
              <button
                onClick={() => handleCopy("AMARACHI GRACE NJOKU", "name")}
                className="p-2 hover:bg-primary/10 rounded-lg transition-colors"
              >
                {copiedField === "name" ? (
                  <Check size={18} className="text-green-600" />
                ) : (
                  <Copy size={18} className="text-muted-foreground" />
                )}
              </button>
            </div>
          </div>

          {/* Account Number */}
          <div className="bg-white border-2 border-border rounded-2xl p-4">
            <p className="text-xs text-muted-foreground mb-2">Account Number</p>
            <div className="flex items-center justify-between">
              <p className="text-2xl font-bold text-primary font-mono">
                9054284702
              </p>
              <button
                onClick={() => handleCopy("9054284702", "number")}
                className="p-2 hover:bg-primary/10 rounded-lg transition-colors flex-shrink-0"
              >
                {copiedField === "number" ? (
                  <Check size={20} className="text-green-600" />
                ) : (
                  <Copy size={20} className="text-muted-foreground" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Instructions */}
        <div className="bg-yellow-50 border-2 border-yellow-200 rounded-2xl p-4 mb-8">
          <p className="text-sm text-yellow-900 font-semibold mb-2">
            📋 Important Instructions:
          </p>
          <ul className="text-sm text-yellow-900 space-y-1 list-disc list-inside">
            <li>Transfer exactly ₦4,500 to the account above</li>
            <li>Use your full name as the transfer description</li>
            <li>Keep your transaction reference for verification</li>
          </ul>
        </div>

        {/* Success Note */}
        <div className="bg-green-50 border-2 border-green-200 rounded-2xl p-4 mb-8">
          <p className="text-sm text-green-900">
            <span className="font-semibold">✅ Note:</span> Your Personal Code
            will be sent to your WhatsApp or Email once your payment is
            successful.
          </p>
        </div>

        {/* Made Transfer Button */}
        <button
          onClick={handleMadeTransfer}
          className="w-full bg-primary text-primary-foreground font-semibold py-3 rounded-xl hover:bg-primary/90 transition-all active:scale-95"
        >
          I Have Made Transfer
        </button>
      </div>
    </div>
  );
}
