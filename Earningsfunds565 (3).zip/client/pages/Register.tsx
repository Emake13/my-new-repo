import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useUser } from '@/context/UserContext';
import { ArrowLeft, Eye, EyeOff, AlertCircle } from 'lucide-react';

export default function Register() {
  const navigate = useNavigate();
  const { register } = useUser();
  const [searchParams] = useSearchParams();
  const [referralCode, setReferralCode] = useState<string | null>(null);

  useEffect(() => {
    const ref = searchParams.get('ref');
    if (ref) {
      setReferralCode(ref);
    }
  }, [searchParams]);

  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
  });

  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.fullName.trim()) {
      newErrors.fullName = 'Full name is required';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email';
    }

    if (!formData.password.trim()) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    if (errors[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: '',
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setLoading(true);
    try {
      await register(formData.fullName, formData.email, formData.password, referralCode || undefined);
      navigate('/');
    } catch (error) {
      setErrors({
        submit: error instanceof Error ? error.message : 'Registration failed',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-secondary to-white pb-12 flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-br from-primary to-primary/90 text-primary-foreground px-6 py-6 sticky top-0 z-30">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="hover:opacity-80 transition-opacity">
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-2xl font-bold">Create Account</h1>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-foreground mb-2">
            Welcome to Earn Bye Naira
          </h2>
          <p className="text-muted-foreground">
            Sign up to get started with ₦50,000 welcome bonus
          </p>
          {referralCode && (
            <div className="mt-4 bg-green-50 border-2 border-green-200 rounded-xl p-3">
              <p className="text-sm text-green-900">
                <span className="font-semibold">✓ Referral Code Valid:</span> You were referred to Earn Bye Naira! Your referrer will earn ₦5,000 when you complete registration.
              </p>
            </div>
          )}
        </div>

        {/* Registration Form */}
        <form onSubmit={handleSubmit} className="space-y-5 mb-8">
          {/* Full Name */}
          <div>
            <label htmlFor="fullName" className="block text-sm font-semibold text-foreground mb-2">
              Full Name
            </label>
            <input
              type="text"
              id="fullName"
              name="fullName"
              value={formData.fullName}
              onChange={handleInputChange}
              placeholder="Enter your full name"
              className={`w-full px-4 py-3 rounded-xl border-2 transition-colors focus:outline-none ${
                errors.fullName
                  ? 'border-destructive bg-destructive/5 focus:border-destructive'
                  : 'border-input bg-input focus:border-primary'
              }`}
            />
            {errors.fullName && (
              <p className="text-xs text-destructive mt-1 flex items-center gap-1">
                <AlertCircle size={14} />
                {errors.fullName}
              </p>
            )}
          </div>

          {/* Email */}
          <div>
            <label htmlFor="email" className="block text-sm font-semibold text-foreground mb-2">
              Email Address
            </label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
              placeholder="your@email.com"
              className={`w-full px-4 py-3 rounded-xl border-2 transition-colors focus:outline-none ${
                errors.email
                  ? 'border-destructive bg-destructive/5 focus:border-destructive'
                  : 'border-input bg-input focus:border-primary'
              }`}
            />
            {errors.email && (
              <p className="text-xs text-destructive mt-1 flex items-center gap-1">
                <AlertCircle size={14} />
                {errors.email}
              </p>
            )}
          </div>

          {/* Password */}
          <div>
            <label htmlFor="password" className="block text-sm font-semibold text-foreground mb-2">
              Password
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                id="password"
                name="password"
                value={formData.password}
                onChange={handleInputChange}
                placeholder="Create a password"
                className={`w-full px-4 py-3 rounded-xl border-2 transition-colors focus:outline-none pr-12 ${
                  errors.password
                    ? 'border-destructive bg-destructive/5 focus:border-destructive'
                    : 'border-input bg-input focus:border-primary'
                }`}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
            {errors.password && (
              <p className="text-xs text-destructive mt-1 flex items-center gap-1">
                <AlertCircle size={14} />
                {errors.password}
              </p>
            )}
          </div>

          {/* Submit Error */}
          {errors.submit && (
            <div className="bg-destructive/10 border-2 border-destructive rounded-xl p-4">
              <p className="text-sm text-destructive flex items-center gap-2">
                <AlertCircle size={16} />
                {errors.submit}
              </p>
            </div>
          )}

          {/* Register Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-primary text-primary-foreground font-semibold py-3 rounded-xl hover:bg-primary/90 transition-all active:scale-95 disabled:opacity-75 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
                Creating Account...
              </>
            ) : (
              'Create Account'
            )}
          </button>
        </form>

        {/* Already Have Account */}
        <div className="text-center mb-8">
          <p className="text-muted-foreground text-sm">
            Already have an account?{' '}
            <button
              onClick={() => navigate('/login')}
              className="text-primary font-semibold hover:underline"
            >
              Sign In
            </button>
          </p>
        </div>

        {/* Benefits Section */}
        <div className="mt-8 bg-white border border-border rounded-2xl p-6">
          <h3 className="font-semibold text-foreground mb-4">What You Get</h3>
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <div className="text-2xl">🎁</div>
              <div>
                <p className="font-semibold text-foreground text-sm">₦50,000 Welcome Bonus</p>
                <p className="text-xs text-muted-foreground">Instant credit to your account</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="text-2xl">📅</div>
              <div>
                <p className="font-semibold text-foreground text-sm">₦1,000 Daily Bonus</p>
                <p className="text-xs text-muted-foreground">Claim every 24 hours</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="text-2xl">👥</div>
              <div>
                <p className="font-semibold text-foreground text-sm">Referral Earnings</p>
                <p className="text-xs text-muted-foreground">Earn ₦5,000 per referral</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="text-2xl">💸</div>
              <div>
                <p className="font-semibold text-foreground text-sm">Easy Withdrawals</p>
                <p className="text-xs text-muted-foreground">Transfer to your bank instantly</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
