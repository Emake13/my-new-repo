import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Star, Crown, Zap, Gem, Trophy, Upload, Copy, Check } from "lucide-react";
import { LoadingScreen } from "@/components/LoadingScreen";

interface Plan {
  id: number;
  name: string;
  price: number;
  dailyReward: number;
  icon: React.ReactNode;
  color: string;
  badge: string;
}

const plans: Plan[] = [
  {
    id: 1,
    name: "Starter Plan",
    price: 3000,
    dailyReward: 5000,
    icon: <Star size={32} />,
    color: "from-blue-400 to-blue-600",
    badge: "Popular"
  },
  {
    id: 2,
    name: "Silver Plan",
    price: 5000,
    dailyReward: 8000,
    icon: <Zap size={32} />,
    color: "from-gray-400 to-gray-600",
    badge: "Recommended"
  },
  {
    id: 3,
    name: "Gold Plan",
    price: 10000,
    dailyReward: 15000,
    icon: <Gem size={32} />,
    color: "from-yellow-400 to-yellow-600",
    badge: "Best Value"
  },
  {
    id: 4,
    name: "Premium Plan",
    price: 20000,
    dailyReward: 30000,
    icon: <Crown size={32} />,
    color: "from-purple-400 to-purple-600",
    badge: "Exclusive"
  },
  {
    id: 5,
    name: "VIP Plan",
    price: 50000,
    dailyReward: 70000,
    icon: <Trophy size={32} />,
    color: "from-red-400 to-red-600",
    badge: "Elite"
  }
];

type PaymentModalState = 'closed' | 'payment' | 'receipt' | 'loading' | 'failed';

export default function UpgradePlans() {
  const navigate = useNavigate();
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [modalState, setModalState] = useState<PaymentModalState>('closed');
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [receiptFile, setReceiptFile] = useState<File | null>(null);
  const [receiptPreview, setReceiptPreview] = useState<string | null>(null);

  const handleCopy = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleUpgradeClick = (plan: Plan) => {
    setSelectedPlan(plan);
    setModalState('payment');
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setReceiptFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setReceiptPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePaymentConfirm = () => {
    if (!receiptFile) {
      alert("Please upload a payment receipt");
      return;
    }
    setModalState('loading');
    setTimeout(() => {
      setModalState('failed');
    }, 3000);
  };

  const handleClose = () => {
    setModalState('closed');
    setSelectedPlan(null);
    setReceiptFile(null);
    setReceiptPreview(null);
  };

  const formatNaira = (amount: number) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  if (modalState === 'loading') {
    return <LoadingScreen />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/5 to-white pb-24">
      {/* Header */}
      <div className="bg-gradient-to-br from-primary to-primary/90 text-primary-foreground px-6 py-6 sticky top-0 z-30">
        <div className="flex items-center gap-4 mb-2">
          <button onClick={() => navigate("/")} className="hover:opacity-80 transition-opacity">
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-2xl font-bold">Upgrade Plans</h1>
        </div>
        <p className="text-primary-foreground/80 text-sm">Choose a plan and start earning more</p>
      </div>

      {/* Content */}
      <div className="px-6 py-8">
        {/* Intro Section */}
        <div className="mb-8">
          <p className="text-foreground text-center text-sm leading-relaxed">
            Select an upgrade plan to increase your daily earnings. The more you invest, the more you earn daily!
          </p>
        </div>

        {/* Plans Grid */}
        <div className="space-y-4">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className={`relative overflow-hidden rounded-2xl border-2 border-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-102 bg-white`}
            >
              {/* Badge */}
              <div className={`absolute top-0 right-0 bg-gradient-to-r ${plan.color} text-white px-3 py-1 text-xs font-bold rounded-bl-lg`}>
                {plan.badge}
              </div>

              {/* Plan Content */}
              <div className="p-6">
                {/* Icon and Title */}
                <div className="flex items-start gap-4 mb-4">
                  <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${plan.color} text-white flex items-center justify-center flex-shrink-0`}>
                    {plan.icon}
                  </div>
                  <div className="flex-1 pt-1">
                    <h3 className="text-lg font-bold text-foreground">{plan.name}</h3>
                  </div>
                </div>

                {/* Price and Reward */}
                <div className="bg-gradient-to-r from-primary/5 to-primary/10 rounded-xl p-4 mb-5">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs text-muted-foreground font-medium mb-1">Investment</p>
                      <p className="text-2xl font-bold text-primary">{formatNaira(plan.price)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground font-medium mb-1">Daily Earnings</p>
                      <p className="text-2xl font-bold text-green-600">{formatNaira(plan.dailyReward)}</p>
                    </div>
                  </div>
                </div>

                {/* ROI Info */}
                <div className="mb-5">
                  <p className="text-xs text-muted-foreground">
                    📊 You'll earn back your investment in{" "}
                    <span className="font-bold text-primary">
                      {Math.ceil(plan.price / plan.dailyReward)} days
                    </span>
                  </p>
                </div>

                {/* Upgrade Button */}
                <button
                  onClick={() => handleUpgradeClick(plan)}
                  className={`w-full py-3 px-4 rounded-xl font-bold text-white transition-all active:scale-95 bg-gradient-to-r ${plan.color} hover:shadow-lg`}
                >
                  Upgrade Now
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Info Section */}
        <div className="mt-10 bg-blue-50 border-2 border-blue-200 rounded-2xl p-5">
          <h4 className="font-bold text-foreground mb-3 flex items-center gap-2">
            ℹ️ How It Works
          </h4>
          <ul className="space-y-2 text-sm text-foreground">
            <li className="flex items-start gap-2">
              <span className="text-primary font-bold">✓</span>
              <span>Choose your upgrade plan</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary font-bold">✓</span>
              <span>Make a bank transfer to the provided account</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary font-bold">✓</span>
              <span>Upload your payment receipt</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary font-bold">✓</span>
              <span>Start earning your daily rewards immediately</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Payment Modal */}
      {(modalState === 'payment' || modalState === 'receipt') && selectedPlan && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-end">
          <div className="bg-white w-full rounded-t-3xl max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-primary to-primary/90 text-primary-foreground px-6 py-5 sticky top-0 z-10 flex justify-between items-center">
              <h2 className="text-xl font-bold">
                {modalState === 'payment' ? 'Payment Details' : 'Upload Receipt'}
              </h2>
              <button
                onClick={handleClose}
                className="text-2xl hover:opacity-70 transition-opacity"
              >
                ✕
              </button>
            </div>

            <div className="p-6">
              {/* Amount Card */}
              {modalState === 'payment' && (
                <div className="bg-gradient-to-br from-primary/10 to-primary/5 border-2 border-primary rounded-2xl p-5 mb-6">
                  <p className="text-sm text-muted-foreground mb-2">Amount to Transfer</p>
                  <h3 className="text-3xl font-bold text-primary">{formatNaira(selectedPlan.price)}</h3>
                  <p className="text-xs text-muted-foreground mt-2">
                    {selectedPlan.name} - Daily Earnings: {formatNaira(selectedPlan.dailyReward)}
                  </p>
                </div>
              )}

              {/* Payment Details */}
              {modalState === 'payment' && (
                <div className="space-y-4 mb-8">
                  <h3 className="text-lg font-bold text-foreground mb-4">Bank Details</h3>

                  {/* Bank Name */}
                  <div className="bg-white border-2 border-border rounded-2xl p-4">
                    <p className="text-xs text-muted-foreground mb-2">Bank Name</p>
                    <div className="flex items-center justify-between">
                      <p className="text-lg font-semibold text-foreground">PalmPay Limited(PalmPay)</p>
                      <button
                        onClick={() => handleCopy("PalmPay Limited(PalmPay)", "bank")}
                        className="p-2 hover:bg-primary/10 rounded-lg transition-colors"
                      >
                        {copiedField === "bank" ? (
                          <Check size={18} className="text-green-600" />
                        ) : (
                          <Copy size={18} className="text-muted-foreground" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Account Name */}
                  <div className="bg-white border-2 border-border rounded-2xl p-4">
                    <p className="text-xs text-muted-foreground mb-2">Account Name</p>
                    <div className="flex items-center justify-between">
                      <p className="text-lg font-semibold text-foreground">AMARACHI GRACE NJOKU</p>
                      <button
                        onClick={() => handleCopy("AMARACHI GRACE NJOKU", "name")}
                        className="p-2 hover:bg-primary/10 rounded-lg transition-colors"
                      >
                        {copiedField === "name" ? (
                          <Check size={18} className="text-green-600" />
                        ) : (
                          <Copy size={18} className="text-muted-foreground" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Account Number */}
                  <div className="bg-white border-2 border-border rounded-2xl p-4">
                    <p className="text-xs text-muted-foreground mb-2">Account Number</p>
                    <div className="flex items-center justify-between">
                      <p className="text-2xl font-bold text-primary font-mono">9054284702</p>
                      <button
                        onClick={() => handleCopy("9054284702", "number")}
                        className="p-2 hover:bg-primary/10 rounded-lg transition-colors flex-shrink-0"
                      >
                        {copiedField === "number" ? (
                          <Check size={20} className="text-green-600" />
                        ) : (
                          <Copy size={20} className="text-muted-foreground" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Receipt Upload */}
              {modalState === 'receipt' && (
                <div className="space-y-4 mb-8">
                  <h3 className="text-lg font-bold text-foreground mb-4">Upload Payment Receipt</h3>

                  {/* Upload Area */}
                  <div className="border-2 border-dashed border-primary/30 rounded-2xl p-6 text-center bg-primary/5 hover:bg-primary/10 transition-colors cursor-pointer">
                    <label htmlFor="receipt-upload" className="cursor-pointer block">
                      <div className="flex flex-col items-center gap-3">
                        <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                          <Upload size={24} className="text-primary" />
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-foreground">
                            {receiptFile ? receiptFile.name : "Click to upload"}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            PNG, JPG, or PDF (Max 10MB)
                          </p>
                        </div>
                      </div>
                      <input
                        id="receipt-upload"
                        type="file"
                        accept="image/*,.pdf"
                        onChange={handleFileSelect}
                        className="hidden"
                      />
                    </label>
                  </div>

                  {/* Preview */}
                  {receiptPreview && (
                    <div className="border-2 border-border rounded-2xl p-3 overflow-hidden">
                      <p className="text-xs text-muted-foreground mb-2">Preview</p>
                      <img
                        src={receiptPreview}
                        alt="Receipt preview"
                        className="w-full rounded-lg object-cover max-h-64"
                      />
                    </div>
                  )}

                  {/* Info */}
                  <div className="bg-yellow-50 border-2 border-yellow-200 rounded-2xl p-4">
                    <p className="text-sm text-yellow-900">
                      <span className="font-semibold">📸 Tip:</span> Make sure the payment receipt is clear and shows the amount {formatNaira(selectedPlan.price)}, account number, and timestamp.
                    </p>
                  </div>
                </div>
              )}

              {/* Buttons */}
              <div className="space-y-3 pb-4">
                {modalState === 'payment' && (
                  <button
                    onClick={() => setModalState('receipt')}
                    className="w-full bg-primary text-primary-foreground font-bold py-3 rounded-xl hover:bg-primary/90 transition-all active:scale-95"
                  >
                    I Have Paid
                  </button>
                )}

                {modalState === 'receipt' && (
                  <button
                    onClick={handlePaymentConfirm}
                    className="w-full bg-primary text-primary-foreground font-bold py-3 rounded-xl hover:bg-primary/90 transition-all active:scale-95 flex items-center justify-center gap-2"
                  >
                    <Check size={20} />
                    Confirm Payment
                  </button>
                )}

                <button
                  onClick={handleClose}
                  className="w-full bg-gray-100 text-foreground font-bold py-3 rounded-xl hover:bg-gray-200 transition-all active:scale-95"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Payment Failed Modal */}
      {modalState === 'failed' && selectedPlan && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-end">
          <div className="bg-white w-full rounded-t-3xl max-h-[90vh] overflow-y-auto">
            {/* Modal Content */}
            <div className="p-8 text-center">
              <div className="w-20 h-20 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-6">
                <svg className="w-10 h-10 text-red-600" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" stroke="currentColor">
                  <path d="M6 18L18 6M6 6l12 12"></path>
                </svg>
              </div>

              <h2 className="text-2xl font-bold text-foreground mb-3">Payment Not Received</h2>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                Your payment has not been confirmed yet. Please contact support if you have already made the transfer.
              </p>

              {/* Support Info */}
              <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-4 mb-6 text-left">
                <p className="text-sm font-semibold text-foreground mb-2">Need Help?</p>
                <p className="text-sm text-muted-foreground mb-3">
                  If you've already made the transfer, please contact our support team with your transaction reference.
                </p>
                <button className="w-full bg-primary text-primary-foreground font-bold py-2 rounded-lg hover:bg-primary/90 transition-all">
                  Contact Support
                </button>
              </div>

              {/* Close Button */}
              <button
                onClick={handleClose}
                className="w-full bg-primary text-primary-foreground font-bold py-3 rounded-xl hover:bg-primary/90 transition-all active:scale-95"
              >
                Go Back
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
