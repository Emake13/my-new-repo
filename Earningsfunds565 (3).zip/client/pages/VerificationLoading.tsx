import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function VerificationLoading() {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate("/not-verified-result");
    }, 8000);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary to-primary/90 flex flex-col items-center justify-center text-center text-primary-foreground px-6">
      {/* Spinning Circle */}
      <div className="mb-8">
        <div className="w-20 h-20 border-4 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin"></div>
      </div>

      {/* Text */}
      <h1 className="text-3xl font-bold mb-3">Verifying your transfer…</h1>
      <p className="text-lg text-primary-foreground/90 max-w-xs">
        Please wait while we confirm your bank transfer.
      </p>

      {/* Loading Dots */}
      <div className="flex gap-2 mt-8">
        <div className="w-2 h-2 bg-primary-foreground rounded-full animate-pulse"></div>
        <div
          className="w-2 h-2 bg-primary-foreground rounded-full animate-pulse"
          style={{ animationDelay: "0.2s" }}
        ></div>
        <div
          className="w-2 h-2 bg-primary-foreground rounded-full animate-pulse"
          style={{ animationDelay: "0.4s" }}
        ></div>
      </div>
    </div>
  );
}
