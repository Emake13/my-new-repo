import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, AlertCircle } from "lucide-react";

export default function BuyPersonalCode() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    whatsappNumber: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.fullName.trim()) {
      newErrors.fullName = "Full name is required";
    }

    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Please enter a valid email";
    }

    if (!formData.whatsappNumber.trim()) {
      newErrors.whatsappNumber = "WhatsApp number is required";
    } else if (!/^[\d+\s\-()]{10,}$/.test(formData.whatsappNumber)) {
      newErrors.whatsappNumber = "Please enter a valid phone number";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    if (errors[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: "",
      }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    // Store form data in sessionStorage for next page
    sessionStorage.setItem("personalCodeFormData", JSON.stringify(formData));
    navigate("/payment-processing");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-secondary to-white pb-12 flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-br from-primary to-primary/90 text-primary-foreground px-6 py-6 sticky top-0 z-30">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate(-1)}
            className="hover:opacity-80 transition-opacity"
          >
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-2xl font-bold">Buy Personal Code</h1>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6 py-8">
        {/* Amount Card */}
        <div className="bg-white border-2 border-primary rounded-2xl p-6 mb-8">
          <p className="text-sm text-muted-foreground mb-2">Amount to Pay</p>
          <h2 className="text-4xl font-bold text-primary">₦4,500</h2>
          <p className="text-xs text-muted-foreground mt-2">
            Fixed amount for personal code
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-5 mb-8">
          {/* Full Name */}
          <div>
            <label
              htmlFor="fullName"
              className="block text-sm font-semibold text-foreground mb-2"
            >
              Full Name
            </label>
            <input
              type="text"
              id="fullName"
              name="fullName"
              value={formData.fullName}
              onChange={handleInputChange}
              placeholder="Enter your full name"
              className={`w-full px-4 py-3 rounded-xl border-2 transition-colors focus:outline-none ${
                errors.fullName
                  ? "border-destructive bg-destructive/5 focus:border-destructive"
                  : "border-input bg-input focus:border-primary"
              }`}
            />
            {errors.fullName && (
              <p className="text-xs text-destructive mt-1 flex items-center gap-1">
                <AlertCircle size={14} />
                {errors.fullName}
              </p>
            )}
          </div>

          {/* Email */}
          <div>
            <label
              htmlFor="email"
              className="block text-sm font-semibold text-foreground mb-2"
            >
              Email Address
            </label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
              placeholder="your@email.com"
              className={`w-full px-4 py-3 rounded-xl border-2 transition-colors focus:outline-none ${
                errors.email
                  ? "border-destructive bg-destructive/5 focus:border-destructive"
                  : "border-input bg-input focus:border-primary"
              }`}
            />
            {errors.email && (
              <p className="text-xs text-destructive mt-1 flex items-center gap-1">
                <AlertCircle size={14} />
                {errors.email}
              </p>
            )}
          </div>

          {/* WhatsApp Number */}
          <div>
            <label
              htmlFor="whatsappNumber"
              className="block text-sm font-semibold text-foreground mb-2"
            >
              WhatsApp Number
            </label>
            <input
              type="tel"
              id="whatsappNumber"
              name="whatsappNumber"
              value={formData.whatsappNumber}
              onChange={handleInputChange}
              placeholder="+234 80 1234 5678"
              className={`w-full px-4 py-3 rounded-xl border-2 transition-colors focus:outline-none ${
                errors.whatsappNumber
                  ? "border-destructive bg-destructive/5 focus:border-destructive"
                  : "border-input bg-input focus:border-primary"
              }`}
            />
            {errors.whatsappNumber && (
              <p className="text-xs text-destructive mt-1 flex items-center gap-1">
                <AlertCircle size={14} />
                {errors.whatsappNumber}
              </p>
            )}
          </div>

          {/* Pay Button */}
          <button
            type="submit"
            className="w-full bg-primary text-primary-foreground font-semibold py-3 rounded-xl hover:bg-primary/90 transition-all active:scale-95 flex items-center justify-center gap-2 mt-8"
          >
            Pay ₦4,500
          </button>
        </form>

        {/* Info Section */}
        <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4">
          <p className="text-sm text-blue-900">
            <span className="font-semibold">ℹ️ Info:</span> Your personal code
            will be sent to your WhatsApp or Email once payment is confirmed.
          </p>
        </div>
      </div>
    </div>
  );
}
