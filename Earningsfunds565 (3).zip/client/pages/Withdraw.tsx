import React, { useState } from "react";
import { useUser } from "@/context/UserContext";
import { Navigation } from "@/components/Navigation";
import { LoadingScreen } from "@/components/LoadingScreen";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

const NIGERIAN_BANKS = [
  "Access Bank",
  "Ecobank",
  "FCMB",
  "First Bank",
  "Fidelity Bank",
  "GTBank",
  "Heritage Bank",
  "Keystone Bank",
  "Kuda Bank",
  "Moniepoint",
  "OPay",
  "PalmPay",
  "Polaris Bank",
  "ProvidusBank",
  "Skye Bank",
  "Stanbic IBTC",
  "Standard Chartered",
  "Sterling Bank",
  "Sunub Bank",
  "Titan Bank",
  "UBA",
  "UNIMEMBER",
  "United Bank For Africa",
  "Wema Bank",
  "Zenith Bank",
  "Absa Bank",
  "Cytonn Bank",
  "FINCA Bank",
  "Guaranty Trust Bank",
  "IEL Bank",
];

export default function Withdraw() {
  const { user, withdraw } = useUser();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);

  const [formData, setFormData] = useState({
    accountName: "",
    accountNumber: "",
    bank: "",
    amount: "",
    personalCode: "",
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const CORRECT_PERSONAL_CODE = "28686996";
  const MINIMUM_BALANCE = 150000;
  const canWithdraw = user && user.balance >= MINIMUM_BALANCE;

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.accountName.trim()) {
      newErrors.accountName = "Account name is required";
    }

    if (!formData.accountNumber.trim()) {
      newErrors.accountNumber = "Account number is required";
    } else if (!/^\d{10}$/.test(formData.accountNumber)) {
      newErrors.accountNumber = "Account number must be 10 digits";
    }

    if (!formData.bank) {
      newErrors.bank = "Please select a bank";
    }

    if (!formData.amount) {
      newErrors.amount = "Amount is required";
    } else {
      const amount = parseFloat(formData.amount);
      if (isNaN(amount) || amount <= 0) {
        newErrors.amount = "Please enter a valid amount";
      } else if (user && amount > user.balance) {
        newErrors.amount = "Insufficient balance";
      }
    }

    if (!formData.personalCode.trim()) {
      newErrors.personalCode = "Personal code is required";
    } else if (formData.personalCode !== CORRECT_PERSONAL_CODE) {
      newErrors.personalCode =
        "Invalid Personal Code! Please contact support to buy your personal code.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!canWithdraw) {
      setErrors({
        submit: `Minimum balance of ₦${formatNaira(MINIMUM_BALANCE)} required to withdraw. Keep earning!`,
      });
      return;
    }

    if (!validateForm()) return;

    const amount = parseFloat(formData.amount);

    try {
      setIsLoading(true);
      await withdraw(
        amount,
        formData.bank,
        formData.accountNumber,
        formData.accountName,
      );
      navigate("/withdrawal-success");
    } catch (error) {
      setErrors({
        submit: error instanceof Error ? error.message : "Withdrawal failed",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const formatNaira = (amount: number) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  if (isLoading) return <LoadingScreen />;

  return (
    <div className="min-h-screen bg-white pb-24">
      {/* Header */}
      <div className="bg-gradient-to-br from-primary to-primary/90 text-primary-foreground px-6 py-6 sticky top-0 z-30">
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={() => navigate("/")}
            className="hover:opacity-80 transition-opacity"
          >
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-2xl font-bold">Withdraw Money</h1>
        </div>

        <div className="bg-white/20 backdrop-blur-sm rounded-xl p-4">
          <p className="text-sm opacity-90">Available Balance</p>
          <p className="text-2xl font-bold">
            {user && formatNaira(user.balance)}
          </p>
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="px-6 py-8 space-y-6">
        {errors.submit && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
            {errors.submit}
          </div>
        )}

        {/* Account Name */}
        <div>
          <label className="block text-sm font-semibold text-foreground mb-2">
            Account Name
          </label>
          <input
            type="text"
            value={formData.accountName}
            onChange={(e) => {
              setFormData({ ...formData, accountName: e.target.value });
              if (errors.accountName) {
                setErrors({ ...errors, accountName: "" });
              }
            }}
            placeholder="John Doe"
            className={`w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 transition-colors ${
              errors.accountName
                ? "border-red-500 focus:ring-red-500"
                : "border-border focus:ring-primary"
            }`}
          />
          {errors.accountName && (
            <p className="text-red-600 text-xs mt-1">{errors.accountName}</p>
          )}
        </div>

        {/* Account Number */}
        <div>
          <label className="block text-sm font-semibold text-foreground mb-2">
            Account Number
          </label>
          <input
            type="text"
            value={formData.accountNumber}
            onChange={(e) => {
              const value = e.target.value.replace(/\D/g, "").slice(0, 10);
              setFormData({ ...formData, accountNumber: value });
              if (errors.accountNumber) {
                setErrors({ ...errors, accountNumber: "" });
              }
            }}
            placeholder="0123456789"
            maxLength={10}
            className={`w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 transition-colors ${
              errors.accountNumber
                ? "border-red-500 focus:ring-red-500"
                : "border-border focus:ring-primary"
            }`}
          />
          {errors.accountNumber && (
            <p className="text-red-600 text-xs mt-1">{errors.accountNumber}</p>
          )}
        </div>

        {/* Bank Selection */}
        <div>
          <label className="block text-sm font-semibold text-foreground mb-2">
            Select Bank
          </label>
          <select
            value={formData.bank}
            onChange={(e) => {
              setFormData({ ...formData, bank: e.target.value });
              if (errors.bank) {
                setErrors({ ...errors, bank: "" });
              }
            }}
            className={`w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 transition-colors bg-white ${
              errors.bank
                ? "border-red-500 focus:ring-red-500"
                : "border-border focus:ring-primary"
            }`}
          >
            <option value="">Choose a bank...</option>
            {NIGERIAN_BANKS.map((bank) => (
              <option key={bank} value={bank}>
                {bank}
              </option>
            ))}
          </select>
          {errors.bank && (
            <p className="text-red-600 text-xs mt-1">{errors.bank}</p>
          )}
        </div>

        {/* Amount */}
        <div>
          <label className="block text-sm font-semibold text-foreground mb-2">
            Amount (₦)
          </label>
          <input
            type="number"
            value={formData.amount}
            onChange={(e) => {
              setFormData({ ...formData, amount: e.target.value });
              if (errors.amount) {
                setErrors({ ...errors, amount: "" });
              }
            }}
            placeholder="10000"
            min="1"
            className={`w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 transition-colors ${
              errors.amount
                ? "border-red-500 focus:ring-red-500"
                : "border-border focus:ring-primary"
            }`}
          />
          {errors.amount && (
            <p className="text-red-600 text-xs mt-1">{errors.amount}</p>
          )}
        </div>

        {/* Personal Code */}
        <div>
          <label className="block text-sm font-semibold text-foreground mb-2">
            Personal Code
          </label>
          <input
            type="text"
            value={formData.personalCode}
            onChange={(e) => {
              setFormData({ ...formData, personalCode: e.target.value });
              if (errors.personalCode) {
                setErrors({ ...errors, personalCode: "" });
              }
            }}
            placeholder="Enter your personal code"
            className={`w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 transition-colors ${
              errors.personalCode
                ? "border-red-500 focus:ring-red-500"
                : "border-border focus:ring-primary"
            }`}
          />
          {errors.personalCode && (
            <p className="text-red-600 text-xs mt-1">{errors.personalCode}</p>
          )}
        </div>

        {/* Minimum Balance Warning */}
        {!canWithdraw && (
          <div className="bg-amber-50 border-2 border-amber-200 rounded-xl p-4 mb-6">
            <p className="text-sm text-amber-900 font-semibold mb-2">
              ⚠️ Minimum Balance Required
            </p>
            <p className="text-xs text-amber-800 mb-3">
              You need ₦{formatNaira(MINIMUM_BALANCE)} to withdraw. Keep
              claiming your daily bonus!
            </p>
            <div className="bg-white rounded-lg p-2 text-center">
              <p className="text-xs text-muted-foreground">Current Balance</p>
              <p className="text-lg font-bold text-amber-900">
                {user && formatNaira(user.balance)}
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Need {user && formatNaira(MINIMUM_BALANCE - user.balance)} more
              </p>
            </div>
          </div>
        )}

        {/* Submit Button */}
        <button
          type="submit"
          disabled={!canWithdraw}
          className={`w-full font-semibold py-4 rounded-xl transition-all active:scale-95 mt-8 ${
            canWithdraw
              ? "bg-primary text-primary-foreground hover:bg-primary/90"
              : "bg-gray-300 text-gray-600 cursor-not-allowed"
          }`}
        >
          {canWithdraw ? "Request Withdrawal" : "Insufficient Balance"}
        </button>

        <p className="text-xs text-muted-foreground text-center mt-4">
          Withdrawals are processed within 24 hours to your registered bank
          account.
        </p>
      </form>

      <Navigation />
    </div>
  );
}
