import React from "react";
import { Navigation } from "@/components/Navigation";
import {
  ArrowLeft,
  Send,
  Mail,
  Clock,
  FileText,
  AlertCircle,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function Support() {
  const navigate = useNavigate();
  const telegramLink = "https://t.me/Tazzachi";

  const faqItems = [
    {
      question: "How do I withdraw my earnings?",
      answer:
        "Go to the Withdraw page, fill in your bank details, and submit. Your funds will be credited within 24 hours.",
    },
    {
      question: "Can I claim the daily bonus multiple times?",
      answer:
        "No, you can only claim the ₦1,000 bonus once per day. The timer resets at midnight.",
    },
    {
      question: "How much can I withdraw at once?",
      answer:
        "You can withdraw any amount up to your current balance. There is no minimum or maximum limit.",
    },
    {
      question: "Is this app legitimate?",
      answer:
        "Yes, we are a registered fintech company. All transactions are secure and your data is protected.",
    },
    {
      question: "How does the referral program work?",
      answer:
        "Share your referral code with friends. When they sign up using your code, you earn ₦5,000 instantly.",
    },
    {
      question: "What if I forgot my PIN/Password?",
      answer:
        "Contact our support team on Telegram and we will help you reset your credentials.",
    },
  ];

  const supportChannels = [
    {
      icon: Send,
      title: "Telegram Support",
      description: "Chat with us on Telegram for instant support",
      action: "Contact on Telegram",
      link: telegramLink,
      color: "bg-blue-50 border-blue-200",
      textColor: "text-blue-700",
    },
    {
      icon: Mail,
      title: "Email Support",
      description: "Send us an email and we will respond within 24 hours",
      action: "support@earnbyenaira.app",
      link: "mailto:support@earnbyenaira.app",
      color: "bg-indigo-50 border-indigo-200",
      textColor: "text-indigo-700",
    },
    {
      icon: Clock,
      title: "Operating Hours",
      description: "We are available 24/7 to assist you",
      action: "Available Anytime",
      color: "bg-purple-50 border-purple-200",
      textColor: "text-purple-700",
    },
  ];

  return (
    <div className="min-h-screen bg-white pb-24">
      {/* Header */}
      <div className="bg-gradient-to-br from-primary to-primary/90 text-primary-foreground px-6 py-6 sticky top-0 z-30">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate("/")} className="hover:opacity-80">
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-2xl font-bold">Support & Help</h1>
        </div>
      </div>

      <div className="px-6 py-8 space-y-8">
        {/* Quick Support Channels */}
        <div>
          <h2 className="text-lg font-bold text-foreground mb-4">
            Get In Touch
          </h2>

          <div className="space-y-3">
            {supportChannels.map((channel) => {
              const Icon = channel.icon;
              return (
                <a
                  key={channel.title}
                  href={channel.link || "#"}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`rounded-xl p-4 border-2 ${channel.color} transition-all hover:shadow-md active:scale-95`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3 flex-1">
                      <Icon className={`${channel.textColor} mt-1`} size={24} />
                      <div>
                        <h3 className="font-semibold text-foreground">
                          {channel.title}
                        </h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          {channel.description}
                        </p>
                      </div>
                    </div>
                    <div className="text-right ml-2">
                      <p
                        className={`font-semibold text-sm ${channel.textColor}`}
                      >
                        {channel.action}
                      </p>
                    </div>
                  </div>
                </a>
              );
            })}
          </div>
        </div>

        {/* Main Telegram CTA */}
        <a
          href={telegramLink}
          target="_blank"
          rel="noopener noreferrer"
          className="block bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-xl p-6 text-center hover:shadow-lg transition-all active:scale-95"
        >
          <div className="flex items-center justify-center gap-2 mb-2">
            <Send size={24} />
            <span className="text-lg font-bold">Chat on Telegram</span>
          </div>
          <p className="text-blue-100 text-sm">@Tazzachi - Available 24/7</p>
        </a>

        {/* Frequently Asked Questions */}
        <div>
          <h2 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2">
            <FileText size={20} className="text-primary" />
            Frequently Asked Questions
          </h2>

          <div className="space-y-3">
            {faqItems.map((item, index) => (
              <details
                key={index}
                className="bg-white border border-border rounded-xl p-4 cursor-pointer hover:border-primary transition-colors group"
              >
                <summary className="font-semibold text-foreground flex items-center justify-between">
                  <span>{item.question}</span>
                  <span className="text-primary group-open:rotate-180 transition-transform">
                    ▼
                  </span>
                </summary>
                <p className="text-muted-foreground text-sm mt-4 leading-relaxed">
                  {item.answer}
                </p>
              </details>
            ))}
          </div>
        </div>

        {/* Important Information */}
        <div className="bg-amber-50 border-2 border-amber-200 rounded-2xl p-6">
          <div className="flex items-start gap-3">
            <AlertCircle className="text-amber-700 mt-1" size={24} />
            <div>
              <h3 className="font-bold text-amber-900 mb-2">
                Important Information
              </h3>
              <ul className="text-sm text-amber-800 space-y-2">
                <li>• Never share your password with anyone</li>
                <li>• Always verify you are on the official app</li>
                <li>• We will never ask for your bank password</li>
                <li>• Report suspicious activity immediately</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Additional Help */}
        <div className="bg-primary/5 rounded-2xl p-6 border border-primary/20">
          <h3 className="text-lg font-bold text-foreground mb-4">
            Need More Help?
          </h3>
          <p className="text-muted-foreground mb-4">
            Our dedicated support team is ready to help you with any questions
            or issues. Contact us through any of the channels above and we will
            get back to you as soon as possible.
          </p>
          <div className="bg-white rounded-lg p-4 border border-border">
            <p className="text-sm text-foreground mb-2">
              <span className="font-semibold">Response Time:</span> Usually
              within 5 minutes
            </p>
            <p className="text-sm text-foreground">
              <span className="font-semibold">Languages:</span> English, Pidgin,
              Yoruba
            </p>
          </div>
        </div>

        {/* Community */}
        <div className="bg-gradient-to-br from-primary/10 to-secondary rounded-2xl p-6 border border-primary/20">
          <h3 className="text-lg font-bold text-foreground mb-3">
            Join Our Community
          </h3>
          <p className="text-muted-foreground mb-4">
            Connect with other users, share tips, and stay updated with the
            latest news.
          </p>
          <button className="w-full bg-primary text-primary-foreground font-semibold py-3 rounded-xl hover:bg-opacity-90 transition-all active:scale-95">
            Join Community (Coming Soon)
          </button>
        </div>
      </div>

      <Navigation />
    </div>
  );
}
