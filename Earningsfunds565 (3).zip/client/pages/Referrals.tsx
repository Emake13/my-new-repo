import React, { useState } from "react";
import { useUser } from "@/context/UserContext";
import { Navigation } from "@/components/Navigation";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  Copy,
  Share2,
  Users,
  TrendingUp,
  Gift,
  Check,
  Link as LinkIcon,
  Facebook,
  MessageSquare,
  Mail,
} from "lucide-react";

export default function Referrals() {
  const { user, referralLink } = useUser();
  const navigate = useNavigate();
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [showShareMenu, setShowShareMenu] = useState(false);

  const handleCopy = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Earn Bye Naira - Make Money Online",
          text: "Join me on Earn Bye Naira and start earning money! Click the link to sign up with my referral code and we both earn rewards.",
          url: referralLink,
        });
        setShowShareMenu(false);
      } catch (err) {
        console.log("Share cancelled");
      }
    }
  };

  const shareOptions = [
    {
      icon: <MessageSquare size={20} />,
      label: "WhatsApp",
      color: "bg-green-100 text-green-700",
      action: () => {
        const text = `Join me on Earn Bye Naira and start earning money! 💰 ${referralLink}`;
        window.open(`https://wa.me/?text=${encodeURIComponent(text)}`);
        setShowShareMenu(false);
      },
    },
    {
      icon: <Mail size={20} />,
      label: "Email",
      color: "bg-blue-100 text-blue-700",
      action: () => {
        window.open(
          `mailto:?subject=Join Earn Bye Naira&body=Check out Earn Bye Naira: ${referralLink}`
        );
        setShowShareMenu(false);
      },
    },
    {
      icon: <Facebook size={20} />,
      label: "Facebook",
      color: "bg-blue-100 text-blue-700",
      action: () => {
        window.open(
          `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(referralLink)}`
        );
        setShowShareMenu(false);
      },
    },
  ];

  const formatNaira = (amount: number) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/5 to-white pb-24">
      {/* Header */}
      <div className="bg-gradient-to-br from-primary to-primary/90 text-primary-foreground px-6 py-6 sticky top-0 z-30">
        <div className="flex items-center gap-4 mb-2">
          <button onClick={() => navigate("/")} className="hover:opacity-80 transition-opacity">
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-2xl font-bold">Referral Program</h1>
        </div>
        <p className="text-primary-foreground/80 text-sm">Earn ₦5,000 for each friend who joins</p>
      </div>

      {/* Content */}
      <div className="px-6 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          {/* Total Referrals */}
          <div className="bg-gradient-to-br from-blue-400 to-blue-600 text-white rounded-2xl p-5 shadow-lg">
            <div className="flex items-start justify-between mb-3">
              <Users size={28} className="opacity-90" />
              <span className="text-2xl font-bold">{user.referralCount}</span>
            </div>
            <p className="text-sm opacity-90">Total Referrals</p>
            <p className="text-xs opacity-75 mt-1">Friends joined</p>
          </div>

          {/* Referral Earnings */}
          <div className="bg-gradient-to-br from-green-400 to-green-600 text-white rounded-2xl p-5 shadow-lg">
            <div className="flex items-start justify-between mb-3">
              <Gift size={28} className="opacity-90" />
              <span className="text-2xl font-bold">{formatNaira(user.referralEarnings)}</span>
            </div>
            <p className="text-sm opacity-90">Referral Earnings</p>
            <p className="text-xs opacity-75 mt-1">₦5,000 per referral</p>
          </div>
        </div>

        {/* Main Referral Card */}
        <div className="bg-white border-2 border-border rounded-3xl p-6 shadow-lg mb-8">
          <div className="mb-6">
            <h2 className="text-xl font-bold text-foreground mb-2">Your Referral Link</h2>
            <p className="text-sm text-muted-foreground">
              Share this link with friends and earn ₦5,000 for each person who joins using your link.
            </p>
          </div>

          {/* Referral Link Display */}
          <div className="bg-gradient-to-r from-primary/10 to-primary/5 rounded-2xl p-4 mb-4 border border-primary/20">
            <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
              <LinkIcon size={14} />
              Your Referral Link
            </p>
            <p className="text-sm font-mono text-foreground break-all font-semibold mb-3">
              {referralLink}
            </p>
            <button
              onClick={() => handleCopy(referralLink, "link")}
              className={`w-full py-2 px-4 rounded-lg font-semibold transition-all active:scale-95 flex items-center justify-center gap-2 text-sm ${
                copiedField === "link"
                  ? "bg-green-500 text-white"
                  : "bg-primary text-primary-foreground hover:bg-primary/90"
              }`}
            >
              {copiedField === "link" ? (
                <>
                  <Check size={16} />
                  Copied!
                </>
              ) : (
                <>
                  <Copy size={16} />
                  Copy Link
                </>
              )}
            </button>
          </div>

          {/* Share Buttons */}
          <div className="space-y-3">
            {/* Web Share API Button */}
            {navigator.share && (
              <button
                onClick={handleShare}
                className="w-full bg-secondary text-secondary-foreground font-bold py-3 rounded-xl hover:bg-secondary/90 transition-all active:scale-95 flex items-center justify-center gap-2"
              >
                <Share2 size={18} />
                Share Referral Link
              </button>
            )}

            {/* Custom Share Menu */}
            <div className="relative">
              <button
                onClick={() => setShowShareMenu(!showShareMenu)}
                className="w-full bg-primary text-primary-foreground font-bold py-3 rounded-xl hover:bg-primary/90 transition-all active:scale-95 flex items-center justify-center gap-2"
              >
                <Share2 size={18} />
                Share on Social Media
              </button>

              {showShareMenu && (
                <div className="absolute bottom-full left-0 right-0 mb-2 bg-white border-2 border-border rounded-2xl shadow-lg z-10 overflow-hidden">
                  {shareOptions.map((option, index) => (
                    <button
                      key={index}
                      onClick={option.action}
                      className={`w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-50 transition-colors border-b border-border last:border-b-0`}
                    >
                      <div className={`p-2 rounded-lg ${option.color}`}>
                        {option.icon}
                      </div>
                      <span className="text-foreground font-semibold">{option.label}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* How It Works */}
        <div className="bg-gradient-to-br from-blue-50 to-blue-100/50 border-2 border-blue-200 rounded-2xl p-6 mb-8">
          <h3 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2">
            <TrendingUp className="text-primary" size={22} />
            How the Referral Program Works
          </h3>

          <div className="space-y-4">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">
                1
              </div>
              <div>
                <h4 className="font-semibold text-foreground mb-1">Share Your Link</h4>
                <p className="text-sm text-muted-foreground">
                  Copy and share your unique referral link with friends via WhatsApp, SMS, Email, or any social platform.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">
                2
              </div>
              <div>
                <h4 className="font-semibold text-foreground mb-1">They Register</h4>
                <p className="text-sm text-muted-foreground">
                  Your friends click the link and create their account. They'll get ₦50,000 welcome bonus too!
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">
                3
              </div>
              <div>
                <h4 className="font-semibold text-foreground mb-1">You Earn</h4>
                <p className="text-sm text-muted-foreground">
                  As soon as they complete registration, ₦5,000 is instantly added to your balance!
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">
                4
              </div>
              <div>
                <h4 className="font-semibold text-foreground mb-1">Unlimited Earnings</h4>
                <p className="text-sm text-muted-foreground">
                  Keep referring and earning! There's no limit to how many friends you can refer.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Benefits Section */}
        <div className="bg-white border-2 border-border rounded-2xl p-6 mb-8">
          <h3 className="text-lg font-bold text-foreground mb-4">Why Share Your Link?</h3>

          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <div className="text-2xl">💰</div>
              <div>
                <p className="font-semibold text-foreground text-sm">Passive Income</p>
                <p className="text-xs text-muted-foreground">Earn money while you sleep</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="text-2xl">🎁</div>
              <div>
                <p className="font-semibold text-foreground text-sm">High Commission</p>
                <p className="text-xs text-muted-foreground">₦5,000 per successful referral</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="text-2xl">⚡</div>
              <div>
                <p className="font-semibold text-foreground text-sm">Instant Credits</p>
                <p className="text-xs text-muted-foreground">Earn instantly when friends sign up</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="text-2xl">👥</div>
              <div>
                <p className="font-semibold text-foreground text-sm">Unlimited Referrals</p>
                <p className="text-xs text-muted-foreground">No cap on earnings from referrals</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="text-2xl">🔄</div>
              <div>
                <p className="font-semibold text-foreground text-sm">Auto-Withdrawal</p>
                <p className="text-xs text-muted-foreground">Withdraw referral earnings anytime</p>
              </div>
            </div>
          </div>
        </div>

        {/* Referral Stats Summary */}
        <div className="bg-gradient-to-r from-primary/20 to-primary/10 border-2 border-primary/30 rounded-2xl p-6">
          <h3 className="text-lg font-bold text-foreground mb-4">Your Referral Stats</h3>

          <div className="space-y-3">
            <div className="flex justify-between items-center pb-3 border-b border-primary/20">
              <span className="text-muted-foreground text-sm">Total Referrals</span>
              <span className="text-xl font-bold text-primary">{user.referralCount}</span>
            </div>

            <div className="flex justify-between items-center pb-3 border-b border-primary/20">
              <span className="text-muted-foreground text-sm">Earning Per Referral</span>
              <span className="text-lg font-bold text-green-600">₦5,000</span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-muted-foreground text-sm">Total Referral Income</span>
              <span className="text-xl font-bold text-green-600">{formatNaira(user.referralEarnings)}</span>
            </div>
          </div>

          <div className="mt-4 p-3 bg-white rounded-lg text-center">
            <p className="text-xs text-muted-foreground mb-1">Next Goal</p>
            <p className="text-sm font-semibold text-foreground">
              {10 - user.referralCount} more referrals to earn ₦50,000
            </p>
            <div className="mt-2 h-2 bg-gray-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-primary to-primary/70 transition-all"
                style={{ width: `${Math.min((user.referralCount / 10) * 100, 100)}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      <Navigation />
    </div>
  );
}
