import React, { useState, useEffect } from "react";
import { useUser } from "@/context/UserContext";
import { Navigation } from "@/components/Navigation";
import { CommunityPopup } from "@/components/CommunityPopup";
import { useNavigate } from "react-router-dom";
import { Gift, LogOut } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Dashboard() {
  const { user, claimBonus, addDailyBonus, logout } = useUser();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [claiming, setClaiming] = useState(false);
  const [claimError, setClaimError] = useState<string | null>(null);
  const [claimSuccess, setClaimSuccess] = useState(false);
  const [dailyBonusAttempted, setDailyBonusAttempted] = useState(false);

  const handleClaimBonus = async () => {
    setClaiming(true);
    setClaimError(null);
    try {
      await claimBonus();
      setClaimSuccess(true);
      toast({
        title: "✅ Upgraded!",
        description: "Your balance is now ₦150,000",
      });
      setTimeout(() => setClaimSuccess(false), 3000);
    } catch (error) {
      setClaimError(
        error instanceof Error ? error.message : "Failed to claim bonus",
      );
    } finally {
      setClaiming(false);
    }
  };

  useEffect(() => {
    const addDaily = async () => {
      if (!dailyBonusAttempted && user && user.balance >= 150000) {
        try {
          await addDailyBonus();
          toast({
            title: "✅ Daily Bonus!",
            description: "You got ₦500 daily bonus",
          });
        } catch (error) {
          // Silently handle - already claimed today
        }
        setDailyBonusAttempted(true);
      }
    };

    addDaily();
  }, [user, dailyBonusAttempted, addDailyBonus, toast]);

  const formatNaira = (amount: number) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-b from-secondary to-white pb-24">
      {/* Header */}
      <div className="bg-gradient-to-br from-primary to-primary/90 text-primary-foreground px-6 py-8 rounded-b-3xl">
        <div className="flex justify-between items-start mb-8">
          <div>
            <p className="text-sm opacity-90 mb-1">Welcome back</p>
            <h1 className="text-2xl font-bold">{user.name}</h1>
          </div>
          <button
            onClick={() => {
              logout();
              navigate("/login");
            }}
            className="p-2 rounded-full hover:bg-white/20 transition-colors"
          >
            <LogOut size={20} />
          </button>
        </div>

        {/* Balance Card */}
        <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-6 mb-6">
          <p className="text-sm opacity-90 mb-2">Available Balance</p>
          <h2 className="text-4xl font-bold mb-2">
            {formatNaira(user.balance)}
          </h2>
          <p className="text-xs opacity-75">Your earnings so far</p>
        </div>

        {user.balance < 150000 && (
          <>
            {/* Daily Claim */}
            <button
              onClick={handleClaimBonus}
              disabled={claiming}
              className="w-full bg-white text-primary font-semibold py-3 rounded-xl hover:bg-opacity-95 transition-all active:scale-95 disabled:opacity-75 flex items-center justify-center gap-2"
            >
              <Gift size={20} />
              {claiming ? "Claiming..." : "Claim Daily Bonus (₦150,000)"}
            </button>

            {claimError && (
              <p className="text-xs text-white/80 mt-2 text-center bg-red-500/20 rounded-lg py-2">
                {claimError}
              </p>
            )}

            {claimSuccess && (
              <p className="text-xs text-white mt-2 text-center bg-green-500/20 rounded-lg py-2">
                ✅ Bonus claimed! +₦150,000
              </p>
            )}
          </>
        )}
      </div>

      {/* Quick Actions */}
      <div className="px-6 mt-8">
        <h3 className="text-lg font-semibold text-foreground mb-4">
          Quick Actions
        </h3>

        <div className="grid grid-cols-2 gap-4 mb-8">
          <button
            onClick={() => navigate("/withdraw")}
            className="bg-white border-2 border-primary rounded-2xl p-4 text-center hover:bg-primary/5 transition-colors active:scale-95"
          >
            <div className="text-3xl mb-2">💸</div>
            <p className="font-semibold text-foreground text-sm">Withdraw</p>
            <p className="text-xs text-muted-foreground">Cash out</p>
          </button>

          <button
            onClick={() => navigate("/upgrade")}
            className="bg-white border-2 border-primary rounded-2xl p-4 text-center hover:bg-primary/5 transition-colors active:scale-95"
          >
            <div className="text-3xl mb-2">📈</div>
            <p className="font-semibold text-foreground text-sm">Upgrade</p>
            <p className="text-xs text-muted-foreground">Earn more</p>
          </button>

          <button
            onClick={() => navigate("/referrals")}
            className="bg-white border-2 border-primary rounded-2xl p-4 text-center hover:bg-primary/5 transition-colors active:scale-95"
          >
            <div className="text-3xl mb-2">👥</div>
            <p className="font-semibold text-foreground text-sm">Referrals</p>
            <p className="text-xs text-muted-foreground">Earn more</p>
          </button>

          <button
            onClick={() => navigate("/buy-personal-code")}
            className="bg-white border-2 border-primary rounded-2xl p-4 text-center hover:bg-primary/5 transition-colors active:scale-95"
          >
            <div className="text-3xl mb-2">🎫</div>
            <p className="font-semibold text-foreground text-sm">Buy Code</p>
            <p className="text-xs text-muted-foreground">Personal code</p>
          </button>

          <button
            onClick={() => navigate("/support")}
            className="bg-white border-2 border-primary rounded-2xl p-4 text-center hover:bg-primary/5 transition-colors active:scale-95"
          >
            <div className="text-3xl mb-2">💬</div>
            <p className="font-semibold text-foreground text-sm">Support</p>
            <p className="text-xs text-muted-foreground">Help</p>
          </button>

          <button
            onClick={() => navigate("/community")}
            className="bg-white border-2 border-primary rounded-2xl p-4 text-center hover:bg-primary/5 transition-colors active:scale-95"
          >
            <div className="text-3xl mb-2">🌍</div>
            <p className="font-semibold text-foreground text-sm">Community</p>
            <p className="text-xs text-muted-foreground">Connect</p>
          </button>
        </div>

        {/* Referral Section */}
        <button
          onClick={() => navigate("/referrals")}
          className="w-full bg-gradient-to-r from-blue-50 to-blue-100 border-2 border-blue-200 rounded-2xl p-5 mb-8 hover:bg-blue-100 transition-colors active:scale-95 text-left"
        >
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-bold text-foreground text-lg">Your Referrals</h4>
            <span className="text-sm font-semibold text-primary">View More →</span>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-xs text-muted-foreground mb-1">Total Referrals</p>
              <p className="text-2xl font-bold text-foreground">{user.referralCount}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Earned</p>
              <p className="text-2xl font-bold text-green-600">
                {formatNaira(user.referralEarnings)}
              </p>
            </div>
          </div>
        </button>

        {/* Info Section */}
        <div className="bg-primary/5 rounded-2xl p-4 mb-8">
          <h4 className="font-semibold text-foreground mb-3">How It Works</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li className="flex items-start gap-2">
              <span className="text-primary font-bold">✓</span>
              <span>Get ₦50,000 welcome bonus on registration</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary font-bold">✓</span>
              <span>Claim ₦150,000 daily bonus once to upgrade</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary font-bold">✓</span>
              <span>
                Get ₦500 daily bonus automatically every time you return
              </span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary font-bold">✓</span>
              <span>Earn ₦5,000 for each friend who joins via your referral link</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary font-bold">✓</span>
              <span>Withdraw to your bank account anytime</span>
            </li>
          </ul>
        </div>
      </div>

      <Navigation />

      {/* Community Popup */}
      <CommunityPopup />
    </div>
  );
}
