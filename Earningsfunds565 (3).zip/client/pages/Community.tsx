import React from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Navigation } from "@/components/Navigation";

export default function Community() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-secondary to-white pb-24">
      {/* Header */}
      <div className="bg-gradient-to-br from-primary to-primary/90 text-primary-foreground px-6 py-6 sticky top-0 z-30">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate(-1)}
            className="hover:opacity-80 transition-opacity"
          >
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-2xl font-bold">Join Our Community</h1>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-foreground mb-2">
            Connect With Us
          </h2>
          <p className="text-muted-foreground">
            Join our community to stay updated, get support, and connect with
            other users
          </p>
        </div>

        {/* Community Links */}
        <div className="space-y-4 mb-8">
          {/* Telegram Button */}
          <a
            href="https://t.me/earningbyenaria"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full bg-gradient-to-br from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-semibold py-4 rounded-2xl transition-all active:scale-95 flex items-center justify-center gap-3"
          >
            <span className="text-2xl">✈️</span>
            <div className="text-left">
              <p className="font-bold">Join Telegram Channel</p>
              <p className="text-xs text-blue-100">@earningbyenaria</p>
            </div>
          </a>
        </div>

        {/* Benefits Section */}
        <div className="bg-primary/5 rounded-2xl p-6">
          <h3 className="font-semibold text-foreground mb-4">Why Join?</h3>
          <ul className="space-y-3 text-sm text-muted-foreground">
            <li className="flex items-start gap-3">
              <span className="text-2xl">💬</span>
              <span>Get instant support and answers to your questions</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-2xl">📢</span>
              <span>Receive updates about new features and announcements</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-2xl">👥</span>
              <span>Connect with other community members</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-2xl">🎁</span>
              <span>Get exclusive tips and earning strategies</span>
            </li>
          </ul>
        </div>
      </div>

      <Navigation />
    </div>
  );
}
