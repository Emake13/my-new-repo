import React from "react";
import { useNavigate } from "react-router-dom";
import { AlertCircle } from "lucide-react";

export default function NotVerifiedResult() {
  const navigate = useNavigate();

  const handleTryAgain = () => {
    navigate("/buy-personal-code");
  };

  const handleContactSupport = () => {
    navigate("/support");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-secondary to-white pb-12 flex flex-col">
      {/* Error Header */}
      <div className="bg-gradient-to-br from-destructive to-destructive/90 text-primary-foreground px-6 py-12 text-center">
        <div className="mb-4 flex justify-center">
          <AlertCircle size={48} className="text-white" />
        </div>
        <h1 className="text-3xl font-bold mb-2">Transfer Not Verified</h1>
        <p className="text-primary-foreground/90">No payment received yet</p>
      </div>

      {/* Content */}
      <div className="flex-1 px-6 py-8">
        {/* Status Card */}
        <div className="bg-white border-2 border-destructive rounded-2xl p-6 mb-8">
          <div className="text-center">
            <p className="text-sm text-muted-foreground mb-2">Payment Status</p>
            <h2 className="text-2xl font-bold text-destructive">
              ₦4,500 – Not Verified
            </h2>
          </div>
        </div>

        {/* Message */}
        <div className="bg-red-50 border-2 border-red-200 rounded-2xl p-4 mb-8 space-y-3">
          <p className="text-sm text-red-900 font-semibold">
            ⚠️ What happened?
          </p>
          <p className="text-sm text-red-900">
            We haven't received your payment yet. This could happen if:
          </p>
          <ul className="text-sm text-red-900 list-disc list-inside space-y-1">
            <li>The transfer is still processing (can take up to 24 hours)</li>
            <li>The amount was incorrect</li>
            <li>The account details were wrong</li>
            <li>There was a network issue during transfer</li>
          </ul>
        </div>

        {/* Next Steps */}
        <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-4 mb-8">
          <p className="text-sm text-blue-900 font-semibold mb-2">
            📝 Next Steps:
          </p>
          <p className="text-sm text-blue-900">
            If you have made the payment and still see this message, please
            contact our support team. We'll help verify your transfer.
          </p>
        </div>

        {/* Buttons */}
        <div className="space-y-3">
          <button
            onClick={handleTryAgain}
            className="w-full bg-primary text-primary-foreground font-semibold py-3 rounded-xl hover:bg-primary/90 transition-all active:scale-95"
          >
            Try Again
          </button>
          <button
            onClick={handleContactSupport}
            className="w-full bg-white border-2 border-primary text-primary font-semibold py-3 rounded-xl hover:bg-primary/5 transition-all active:scale-95"
          >
            Contact Support
          </button>
        </div>
      </div>
    </div>
  );
}
