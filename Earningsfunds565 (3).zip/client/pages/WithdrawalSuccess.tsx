import React from "react";
import { useNavigate } from "react-router-dom";
import { useUser } from "@/context/UserContext";
import { Check, Copy, Download, Share2 } from "lucide-react";

export default function WithdrawalSuccess() {
  const navigate = useNavigate();
  const { lastWithdrawal } = useUser();
  const [copied, setCopied] = React.useState(false);

  if (!lastWithdrawal) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center px-6">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">No withdrawal data found</p>
          <button
            onClick={() => navigate("/withdraw")}
            className="text-primary font-semibold hover:underline"
          >
            Back to Withdraw
          </button>
        </div>
      </div>
    );
  }

  const formatDate = (isoString: string) => {
    return new Date(isoString).toLocaleString("en-NG", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  };

  const formatNaira = (amount: number) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white pb-24">
      {/* Success Header */}
      <div className="bg-gradient-to-br from-green-500 to-green-600 text-white px-6 py-12 text-center">
        <div className="flex justify-center mb-6">
          <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center animate-bounce">
            <Check size={40} />
          </div>
        </div>
        <h1 className="text-3xl font-bold mb-2">Withdrawal Successful!</h1>
        <p className="text-green-100">Your funds are on their way</p>
      </div>

      {/* Details Card */}
      <div className="px-6 py-8 space-y-6">
        {/* Main Details */}
        <div className="bg-white border-2 border-green-200 rounded-2xl p-6 space-y-5">
          <div>
            <p className="text-sm text-muted-foreground mb-1">
              Amount Withdrawn
            </p>
            <p className="text-4xl font-bold text-green-600">
              {formatNaira(lastWithdrawal.amount)}
            </p>
          </div>

          <div className="border-t border-border pt-4 space-y-4">
            {/* Bank */}
            <div>
              <p className="text-xs uppercase tracking-wide text-muted-foreground mb-1">
                Bank
              </p>
              <p className="text-lg font-semibold text-foreground">
                {lastWithdrawal.bank}
              </p>
            </div>

            {/* Account Number */}
            <div>
              <p className="text-xs uppercase tracking-wide text-muted-foreground mb-1">
                Account Number
              </p>
              <div className="flex items-center gap-2">
                <p className="text-lg font-semibold text-foreground font-mono">
                  {lastWithdrawal.accountNumber}
                </p>
                <button
                  onClick={() => copyToClipboard(lastWithdrawal.accountNumber)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <Copy size={16} className="text-muted-foreground" />
                </button>
              </div>
            </div>

            {/* Account Name */}
            <div>
              <p className="text-xs uppercase tracking-wide text-muted-foreground mb-1">
                Account Name
              </p>
              <p className="text-lg font-semibold text-foreground">
                {lastWithdrawal.accountName}
              </p>
            </div>

            {/* Transaction ID */}
            <div className="bg-gray-50 rounded-lg p-3">
              <p className="text-xs uppercase tracking-wide text-muted-foreground mb-1">
                Transaction ID
              </p>
              <div className="flex items-center gap-2">
                <p className="text-sm font-mono font-semibold text-foreground">
                  {lastWithdrawal.transactionId}
                </p>
                <button
                  onClick={() => copyToClipboard(lastWithdrawal.transactionId)}
                  className="p-1 hover:bg-white rounded transition-colors"
                >
                  <Copy size={14} className="text-muted-foreground" />
                </button>
              </div>
            </div>

            {/* Time */}
            <div>
              <p className="text-xs uppercase tracking-wide text-muted-foreground mb-1">
                Date & Time
              </p>
              <p className="text-sm text-foreground">
                {formatDate(lastWithdrawal.timestamp)}
              </p>
            </div>
          </div>
        </div>

        {/* Status Timeline */}
        <div className="bg-blue-50 border border-blue-200 rounded-2xl p-6">
          <h3 className="font-semibold text-foreground mb-4">
            What Happens Next
          </h3>
          <div className="space-y-4">
            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-green-500 flex items-center justify-center text-white text-sm font-bold">
                ✓
              </div>
              <div>
                <p className="font-semibold text-foreground text-sm">
                  Withdrawal Initiated
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Processing started
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-300 flex items-center justify-center text-white text-sm font-bold">
                2
              </div>
              <div>
                <p className="font-semibold text-foreground text-sm">
                  Bank Processing
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Usually takes 5 minutes - 1 hour
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center text-gray-600 text-sm font-bold">
                3
              </div>
              <div>
                <p className="font-semibold text-foreground text-sm">
                  Funds Received
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Money in your account
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Info Box */}
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4">
          <p className="text-sm text-amber-900">
            <span className="font-semibold">Important:</span> Keep your
            Transaction ID for reference. Funds are usually received within 24
            hours.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3 pt-4">
          <button
            onClick={() =>
              copyToClipboard(JSON.stringify(lastWithdrawal, null, 2))
            }
            className={`w-full flex items-center justify-center gap-2 px-6 py-3 rounded-xl border-2 transition-all active:scale-95 ${
              copied
                ? "bg-green-50 border-green-500 text-green-600"
                : "border-primary text-primary hover:bg-primary/5"
            }`}
          >
            <Copy size={20} />
            {copied ? "Copied to Clipboard!" : "Copy Details"}
          </button>

          <button
            onClick={() => navigate("/")}
            className="w-full flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-primary text-primary-foreground font-semibold hover:bg-primary/90 transition-all active:scale-95"
          >
            Back to Dashboard
          </button>

          <button
            onClick={() => navigate("/withdraw")}
            className="w-full flex items-center justify-center gap-2 px-6 py-3 rounded-xl border-2 border-primary text-primary font-semibold hover:bg-primary/5 transition-all active:scale-95"
          >
            Make Another Withdrawal
          </button>
        </div>

        {/* Need Help */}
        <div className="bg-gray-50 rounded-2xl p-6 text-center">
          <p className="text-sm text-muted-foreground mb-3">
            Need help with your withdrawal?
          </p>
          <a
            href="https://t.me/Tazzachi"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors font-semibold"
          >
            <span>✈️</span>
            Contact Telegram Support
          </a>
        </div>
      </div>
    </div>
  );
}
